package com.example.contacts.modelos

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class ContactosViewModel : ViewModel() {
    private val _contactos = mutableStateOf<List<Contacto>>(emptyList())
    val contactos: State<List<Contacto>>
        get() = _contactos
    private val query = Firebase.firestore.collection("contactos")

    init {
        query.addSnapshotListener { value, _ ->
            if (value != null) {
                _contactos.value = value.toObjects()
            } // Fin If
        } // Fin Listener
    } // Fin init
} // Fin ContactosViewModel