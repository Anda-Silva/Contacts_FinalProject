package com.example.contacts.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.contacts.modelos.Contacto
import com.example.contacts.modelos.ContactosViewModel
import com.example.contacts.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Home_Lista(
    fotoUsuario: String,
    nombreUsuario: String,
    navController: NavController,
    cerrarSesion: () -> Unit,
    viewModel: ContactosViewModel,
) {
    var showMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(),
                        Alignment.Center
                    ) {
                        Text(text = "Contactos")
                    } // Fin Box
                }, // Fin title
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(AppNav.Home_Lista.route) }) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Icon"
                        ) // Fin Icon
                    } // Fin IconButton
                }, // Fin navigationIcon
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .clip(shape = RoundedCornerShape(16.dp)),
                backgroundColor = MaterialTheme.colors.onSurface,
                contentColor = Color(0xFF442c2E),
                elevation = 8.dp,
                actions = {
                    IconButton(onClick = { navController.navigate(AppNav.AddContacto.route) }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null
                        ) // Fin Icon
                    } // Fin IconButton
                    IconButton(onClick = { showMenu = !showMenu }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = null,
                            tint = Color.Black
                        )
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier
                                .width(140.dp)
                                .padding(8.dp),
                        ) {
                            DropdownMenuItem(onClick = {
                                cerrarSesion()
                                Handler(Looper.getMainLooper()).postDelayed({
                                    navController.navigate(AppNav.LoginScreen.route)
                                }, 2000)
                            })
                            {
                                Column(
                                    verticalArrangement = Arrangement.Center,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Image(
                                        painter = rememberAsyncImagePainter(fotoUsuario),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(84.dp)
                                            .clip(RoundedCornerShape(corner = CornerSize(16.dp)))
                                    ) // Fin Box Image
                                    Spacer(modifier = Modifier.height(15.dp))
                                    Text(
                                        textAlign = TextAlign.Center,
                                        color = Color.White,
                                        text = nombreUsuario
                                    )
                                    Spacer(modifier = Modifier.height(15.dp))
                                    Row() {
                                        Icon(
                                            imageVector = Icons.Filled.Logout,
                                            tint = MaterialTheme.colors.onSurface,
                                            contentDescription = "Salir",
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(text = "Salir", color = Color.White)
                                    } // Fin Row
                                } // Fin Column
                            } // Fin DropdownMenuItem
                        } // Fin DropdownMenu
                    } // Fin IconButton
                } // Fin actions
            ) // Fin TopAppBar
        } // Fin topBar
    ) {
        var textUser by remember { mutableStateOf("") }
        var pasa by remember { mutableStateOf(false) }
        fun buscar() = if (textUser == "" || textUser.length <= 2) {
            pasa = false
        } else {
            for (datos in viewModel.contactos.value) {
                if (datos.nombre == textUser) {
                    pasa = true
                } // Fin If Intern
            } // Fin For
        } // // Fin If Externo
        // Fin buscar
        Column {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        TextField(value = textUser, onValueChange = { textUser = it },
                            label = { Text(text = "Buscar...") }
                        )
                        Icon(imageVector = Icons.Default.Search, contentDescription = null,
                            modifier = Modifier
                                .size(50.dp)
                                .clickable { buscar() }
                        )
                    } // Fin Row
                    Spacer(modifier = Modifier.height(10.dp))
                } // Fin item
                if (!pasa) {
                    items(viewModel.contactos.value) { contacto ->
                        ContactoCard(contacto, navController)
                    } // Fin Items
                } else {
                    items(viewModel.contactos.value) { contacto ->
                        if (contacto.nombre == textUser) {
                            ContactoCard(contacto, navController)
                            FloatingActionButton(modifier = Modifier.size(50.dp),
                                onClick = { pasa = false }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Regresar",
                                    tint = Color.White
                                ) // Fin Icon
                            } // Fin del onClick
                        } // Fin If Intern
                    } // Fin Items
                } // Fin If Externo
            } // Fin LazyColumn
        } // Fin Column-Box
    } // Fin Scaffold
} // Fin Home_List

@Composable
fun ContactoCard(contacto: Contacto, navController: NavController) {
    Card(
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .fillMaxWidth()
            .clickable {
                navController.navigate(
                    AppNav.InformacionContacto.new_route(
                        contacto.foto,
                        contacto.nombre,
                        contacto.telefono,
                        contacto.email,
                        contacto.sitio_web_url
                    )
                )
            }, // Fin clickable
        elevation = 2.dp,
        shape = RoundedCornerShape(corner = CornerSize(16.dp))
    ) {
        Row {
            PuppyImage(contacto)
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
                    .align(Alignment.CenterVertically)
            ) {
                Text(text = contacto.nombre, style = MaterialTheme.typography.h6)
                Text(
                    text = "VIEW DETAILS",
                    style = MaterialTheme.typography.caption,
                    color = Color.White
                )
            } // Fin Column
        } // Fin Row
    } // Fin Card
} // Fin ContactoCard

@Composable
fun PuppyImage(contacto: Contacto) {
    Image(
        painter = rememberAsyncImagePainter(contacto.foto),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .padding(8.dp)
            .size(84.dp)
            .clip(RoundedCornerShape(corner = CornerSize(16.dp)))
    ) // Fin Box Image
} // Fin PuppyImage