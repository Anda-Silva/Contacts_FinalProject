package com.example.contacts.modelos

data class DatosUsuario(
    val nombreCorreo : String = "",
    val fotoCorreo : String = ""
)
