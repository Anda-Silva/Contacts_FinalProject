package com.example.contacts.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.contacts.modelos.ContactosViewModel
import com.example.contacts.screens.AddContacto
import com.example.contacts.screens.Home_Lista
import com.example.contacts.screens.InformacionContacto
import com.example.contacts.screens.login.LoginScreen
import com.example.contacts.screens.login.MainViewModel


@Composable
fun AppNavigation(
    avanza: Boolean,
    onClick: () -> Unit,
    cerrarSesion: () -> Unit,
    mainViewModel: MainViewModel,
) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.LoginScreen.route
    ) {
        composable(route = AppNav.LoginScreen.route) {
            if (avanza) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(AppNav.Home_Lista.route)
                    {
                        popUpTo(AppNav.LoginScreen.route) {
                            inclusive = true
                        } // Fin popUpTo
                    } // Fin Modificacion
                } // Fin LaunchedEffect
            } else {
                LoginScreen(
                    navController,
                    isLoading = false,
                    onLoginClick = onClick,
                )
            } // Fin If
        } // Fin Composable
        composable(route = AppNav.AddContacto.route) { AddContacto(navController) }
        composable(route = AppNav.Home_Lista.route) {
            Home_Lista(
                mainViewModel.state.value.fotoCorreo,
                mainViewModel.state.value.nombreCorreo,
                navController,
                cerrarSesion,
                ContactosViewModel()
            ) // Fin Home_Lista
        } // Fin Composable Home_Lista
        composable(route = AppNav.InformacionContacto.route, arguments = listOf(
            navArgument("foto") { type = NavType.StringType },
            navArgument("nombre") { type = NavType.StringType },
            navArgument("telefono") { type = NavType.StringType },
            navArgument("email") { type = NavType.StringType },
            navArgument("sitio_web_url") { type = NavType.StringType }
        )) {
            InformacionContacto(
                navController,
                foto = it.arguments?.getString("foto") ?: "",
                nombre = it.arguments?.getString("nombre") ?: "",
                telefono = it.arguments?.getString("telefono") ?: "",
                email = it.arguments?.getString("email") ?: "",
                sitio_web_url = it.arguments?.getString("sitio_web_url") ?: ""
            ) // Fin InformacionContacto
        } // Fin composable
    } // Fin NavHost
} // Fin AppNavigation