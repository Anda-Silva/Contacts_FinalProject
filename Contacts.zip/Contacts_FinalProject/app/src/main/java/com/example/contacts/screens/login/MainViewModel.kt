package com.example.contacts.screens.login

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.contacts.R
import com.example.contacts.modelos.DatosUsuario
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class MainViewModel : ViewModel() {
    private val isLoading = MutableLiveData(false)
    val avance = MutableLiveData(false)
    val state: MutableState<DatosUsuario> = mutableStateOf(DatosUsuario())
    fun isLoading(): LiveData<Boolean> = isLoading
    fun avance(): LiveData<Boolean> = avance
    fun LoginWithGoogle(activity: Activity) {
        isLoading.postValue(true)
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(activity.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        val client = GoogleSignIn.getClient(activity, gso)
        val signInIntent: Intent = client.getSignInIntent()
        activity.startActivityForResult(signInIntent, 1)
    } // Fin LoginWithGoogle

    fun finishLogin(accountTask: Task<GoogleSignInAccount>) {
        try {
            val account: GoogleSignInAccount? = accountTask.getResult(ApiException::class.java)
            account?.idToken?.let { token ->
                val auth = FirebaseAuth.getInstance()
                val credential = GoogleAuthProvider.getCredential(token, null)
                auth.signInWithCredential(credential).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        var user = auth.currentUser
                        state.value = state.value.copy(
                            nombreCorreo = user?.displayName.toString(),
                            fotoCorreo = user?.photoUrl.toString()
                        )
                        Log.d("Excelente!", "Ingreso el usuario: ${user?.displayName}")
                        avance.postValue(true)
                    } else {
                        Log.d("Error", "No se puede conectar")
                    } // Fin If
                    isLoading.postValue(false)
                }
            }
        } catch (e: ApiException) {
            Log.d(ContentValues.TAG, "signInResult:failed code" + e.statusCode)
            isLoading.postValue(false)
        } // Fin Try
    } // Fin FinishLogin

    fun singOut(activity: Activity) {
        val auth = FirebaseAuth.getInstance()
        val googleSignInClient: GoogleSignInClient
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(activity.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(activity, gso)
        //SignInOut
        auth.signOut()
        googleSignInClient.signOut().addOnSuccessListener {
            avance.postValue(false)
        }
    } // Fin SingOut
} // Fin MainViewModel