package com.example.contacts.screens.login

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Login
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.contacts.R

@Composable
fun LoginScreen(
    navController: NavHostController,
    isLoading: Boolean,
    onLoginClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Image(
                    painter = painterResource(R.drawable.contacts_logo),
                    modifier = Modifier
                        .size(250.dp)
                        .height(150.dp),
                    contentDescription = ""
                )
                Spacer(modifier = Modifier.padding(top = 30.dp))
                Text(text = "¡BIENVENIDOS!")
            } // Fin Column
        } // Fin Box Intern
        Card(
            modifier = Modifier
                .padding(start = 40.dp, end = 40.dp, top = 350.dp)
                .clip(RoundedCornerShape(10.dp))
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp),
            ) {
                Text(
                    modifier = Modifier
                        .padding(40.dp)
                        .fillMaxWidth(),
                    fontSize = 18.sp,
                    text = "LOGIN WITH GOOGLE",
                    textAlign = TextAlign.Center,
                    color = Color.White
                )
                Text(text = "¡POR FAVOR, INICIAR SESION PARA CONTINUAR!.", fontSize = 12.sp)
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (isLoading) {
                        CircularProgressIndicator()
                    } else {
                        Button(
                            onClick = onLoginClick,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            modifier = Modifier
                                .padding(bottom = 20.dp)
                                .fillMaxWidth()
                        )
                        {
                            Icon(
                                imageVector = Icons.Default.Login,
                                contentDescription = null,
                                modifier = Modifier.size(ButtonDefaults.IconSize)
                            )
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text(stringResource(R.string.Login_Cta))
                        } // Fin Button
                    } //  Fin If
                } // Fin Row
            } // Fin Column Intern
        } // Fin Card
    } // Fin Box Extern
    Box(
        contentAlignment = Alignment.BottomCenter,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            LegalText()
        } // Fin Column
    } // Fin Box
} // Fin LoginScreen

@Composable
fun LegalText() {
    val anottatedString = buildAnnotatedString {
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        ) {
            append(stringResource(R.string.Text_Legal1))
        } // Fin withStyle
        append(" ")
        pushStringAnnotation("URL", "app://terms")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.onSurface
            )
        ) {
            append(stringResource(R.string.Text_Legal2))
        } // Fin withStyle
        append(" ")
        pop()
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        ) {
            append(stringResource(R.string.Text_Legal3))
        } // Fin withStyle
        append(" ")
        pushStringAnnotation("URL", "app://privacy")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.onSurface
            )
        ) {
            append(stringResource(R.string.Text_Legal4))
        } // Fin withStyle
        pop()
    } // Fin anottatedString
    Box(contentAlignment = Alignment.Center) {
        ClickableText(
            modifier = Modifier.padding(24.dp),
            text = anottatedString
        ) { offset ->
            anottatedString.getStringAnnotations("URL", offset, offset)
                .firstOrNull()?.let { tag ->
                    Log.d("App", "Ha dado click en ${tag.item}")
                } //fin del Offset
        } // Fin Text
    } // Fin Box
} // Fin LegalText


