package com.example.contacts.screens

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import com.example.contacts.R
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.contacts.modelos.Contacto
import com.example.contacts.nav.AppNav
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddContacto(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar {
                Text(
                    text = "¡FORMULARIO!",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    color = Color.White
                )  // Fin Text
            } // Fin TopAppBar
        }, // Fin topBar
        floatingActionButton = {
            FloatingActionButton(modifier = Modifier.size(50.dp),
                onClick = { navController.navigate(route = AppNav.Home_Lista.route) }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Regresar",
                    tint = Color.White
                ) // Fin Icon
            } // Fin del FAB
        }, // Fin del FAb externo
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent(navController)
    } // Fin de BodyContent()
} // Fin AddScreen

@Composable
fun BodyContent(navController: NavController) {
    var foto by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var sitio_web_url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 30.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Image(
                    modifier = Modifier
                        .size(250.dp)
                        .clip(CircleShape)
                        .border(5.dp, MaterialTheme.colors.onBackground, CircleShape)
                        .padding(all = 10.dp),
                    painter = rememberAsyncImagePainter(R.drawable.crear_contacto),
                    contentDescription = "Imagenes"
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = foto,
                    onValueChange = { foto = it },
                    label = { Text("Foto") },
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(imageVector = Icons.Default.Image, contentDescription = "")
                        } // Fin IconButton
                    } // Fin leadingIcon
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre") },
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = "")
                        } // Fin IconButton
                    } // Fin leadingIcon
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = telefono,
                    onValueChange = { telefono = it },
                    label = { Text("Telefono") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(imageVector = Icons.Default.PhoneIphone, contentDescription = "")
                        } // Fin IconButton
                    } // Fin leadingIcon
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(imageVector = Icons.Default.AlternateEmail, contentDescription = "")
                        } // Fin IconButton
                    } // Fin leadingIcon
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = sitio_web_url,
                    onValueChange = { sitio_web_url = it },
                    label = { Text("Facebook") },
                    leadingIcon = {
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(imageVector = Icons.Default.TravelExplore, contentDescription = "")
                        } // Fin IconButton
                    } // Fin leadingIcon
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        if (foto == "" || nombre == "" || telefono == "" || email == "" || sitio_web_url == "") {
                            error = true
                        } else {
                            val contacto = Contacto(foto, nombre, telefono, email, sitio_web_url)
                            Firebase.firestore.collection("contactos").add(contacto)
                            navController.navigate(AppNav.Home_Lista.route)
                        } // Fin If
                    }, //Fin onClick
                    border = BorderStroke(2.dp, Color.White),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        modifier = Modifier.size(ButtonDefaults.IconSize)
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text(text = "AGREGAR CONTACTO")
                } // Fin Button
                if (error) {
                    AlertDialog()
                } // Fin If
            } // Fin Item
        } // Fin LazyColumn
    } // Fin Box
} // Fin BodyContent

@Composable
fun AlertDialog() {

    val content = LocalContext.current
    val openDialog = remember { mutableStateOf(true) }

    if (openDialog.value) {
        AlertDialog(
            onDismissRequest = { openDialog.value = false },
            title = { Text(text = "¡ERROR!") },
            text = { Text(text = "¡TODOS LOS CAMPOS DEBEN DE ESTAR LLENOS!") },

            confirmButton = {
                TextButton(
                    onClick = {
                        openDialog.value = false
                        Toast.makeText(content, "¡ ✅ ACEPTADO ✅ !", Toast.LENGTH_SHORT).show()
                    } // Fin onClick
                ) {
                    Text(text = "Aceptar")
                } // Fin TextButton
            }, // Fin  confirmButton
            dismissButton = {
                TextButton(
                    onClick = {
                        openDialog.value = false
                        Toast.makeText(content, "¡ ❎ CANCELADO ❎ !", Toast.LENGTH_SHORT).show()
                    } // Fin onClick
                ) {
                    Text(text = "Cancelar")
                } // Fin TextButton
            }, // Fin dismissButton
            contentColor = Color.White
        ) // Fin AlertDialog
    } // Fin If
} // Fin AlertDialog