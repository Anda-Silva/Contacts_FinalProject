package com.example.contacts.nav

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class AppNav(val route: String) {
    object LoginScreen : AppNav(route = "LoginScreen")
    object AddContacto : AppNav(route = "AddContacto")
    object Home_Lista : AppNav(route = "Home_Lista")
    object InformacionContacto :
        AppNav(route = "InformacionContacto/{foto}/{nombre}/{telefono}/{email}/{sitio_web_url}") {
        fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
        fun new_route(
            foto: String,
            nombre: String,
            telefono: String,
            email: String,
            sitio_web_url: String,
        ): String {
            return "InformacionContacto/${foto.encodeUrl()}/$nombre/$telefono/$email/${sitio_web_url.encodeUrl()}"
        } // Fin new_route
    } // Fin InformacionContacto
} // Fin AppNav