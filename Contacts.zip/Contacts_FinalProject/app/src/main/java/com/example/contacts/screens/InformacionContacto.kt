package com.example.contacts.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.contacts.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun InformacionContacto(
    navController: NavController,
    foto: String,
    nombre: String,
    telefono: String,
    email: String,
    sitio_web_url: String,
) {
    Scaffold(
        topBar = {
            BottomBar(navController)
        }, // Fin topBar
    ) {
        BodyInformation(navController, foto, nombre, telefono, email, sitio_web_url)
    } // Fin BodyInformation
} // Fin InformacionContacto

@Composable
fun BottomBar(navController: NavController) {

    val selectedIndex = remember { mutableStateOf(0) }

    BottomNavigation(elevation = 10.dp) {
        BottomNavigationItem(icon = {
            Icon(imageVector = Icons.Default.ArrowBack, "")
        },
            label = { Text(text = "Go Back") },
            selected = (selectedIndex.value == 0),
            onClick = {
                navController.navigate(AppNav.Home_Lista.route)
            })
        BottomNavigationItem(icon = {
            Icon(imageVector = Icons.Default.Info, "")
        },
            label = { Text(text = "Details") },
            selected = (selectedIndex.value == 0),
            onClick = {
                selectedIndex.value = 2
            })
        BottomNavigationItem(icon = {
            Icon(
                imageVector = Icons.Default.PersonAdd, ""
            )
        },
            label = { Text(text = "Add Contact") },
            selected = (selectedIndex.value == 2),
            onClick = {
                navController.navigate(AppNav.AddContacto.route)
            })
    } // Fin BottomNavigation
} // Fin BottomBar

@Composable
fun BodyInformation(
    navController: NavController,
    foto: String,
    nombre: String,
    telefono: String,
    email: String,
    sitio_web_url: String,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(30.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Image(
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .border(5.dp, Color.White, CircleShape),
            painter = rememberAsyncImagePainter(foto),
            contentDescription = "Imagen",
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.height(30.dp))
        LazyColumn(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Text(
                    text = nombre,
                    style = MaterialTheme.typography.h4
                )
                Spacer(modifier = Modifier.height(30.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {}
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Text(text = "Llamar", color = Color.White)
                    } // Fin Column Llamar
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {}
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Text(text = "Mensajes", color = Color.White)
                    } // Fin Column Mensajes
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {}
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mail,
                            contentDescription = null,
                            tint = Color.White,
                        )
                        Text(text = "Email", color = Color.White)
                    } // Fin Column Email
                } // Fin Row
                Spacer(modifier = Modifier.height(40.dp))
                Card(
                    modifier = Modifier
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                        .fillMaxWidth(),
                    elevation = 2.dp,
                    shape = RoundedCornerShape(corner = CornerSize(16.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                tint = Color.White,
                            )
                            Column(
                                modifier = Modifier.width(200.dp),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = telefono,
                                    textAlign = TextAlign.Start
                                )
                            } // Fin Column
                        } // Fin Row
                        Spacer(modifier = Modifier.height(30.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Column(
                                modifier = Modifier.width(200.dp),
                                horizontalAlignment = Alignment.Start
                            )
                            {
                                Text(
                                    text = email,
                                    textAlign = TextAlign.Start,
                                )
                            } // Fin Column
                        } // Fin Row
                        Spacer(modifier = Modifier.height(30.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = Icons.Default.TravelExplore,
                                contentDescription = null,
                                tint = Color.White,
                            )
                            Column(
                                modifier = Modifier.width(200.dp),
                                horizontalAlignment = Alignment.Start
                            )
                            {
                                val uriHandler = LocalUriHandler.current
                                Text(text = "Facebook",
                                    textAlign = TextAlign.Start,
                                    modifier = Modifier.clickable {
                                        uriHandler.openUri(sitio_web_url)
                                    } // Fin Clickable
                                ) //  Fin Text
                            } // Fin Column
                        } // Fin Row
                    } // Fin Column Intern
                } // Fin Card
            } // Fin item
        } // Fin LazyColumn
    } // Fin Column
    // MainScreen(navController)
} // Fin BodyInformation

/*
@RequiresApi(Build.VERSION_CODES.S)
private fun getRenderEffect(): RenderEffect {
    val blurEffect = RenderEffect
        .createBlurEffect(80f, 80f, Shader.TileMode.MIRROR)
    val alphaMatrix = RenderEffect.createColorFilterEffect(
        ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, 0f,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 0f, 1f, 0f, 0f,
                    0f, 0f, 0f, 50f, -5000f
                ) // Fin floatArrayOf
            ) // Fin ColorMatrix
        ) // Fin ColorMatrixColorFilter
    ) // Fin alphaMatrix
    return RenderEffect
        .createChainEffect(alphaMatrix, blurEffect)
} // Fin getRenderEffect

@Composable
fun MainScreen(navController: NavController) {
    val isMenuExtended = remember { mutableStateOf(false) }
    val fabAnimationProgress by animateFloatAsState(
        targetValue = if (isMenuExtended.value) 1f else 0f,
        animationSpec = tween(
            durationMillis = 1000,
            easing = LinearEasing
        )
    ) /// Fin fabAnimationProgress
    val clickAnimationProgress by animateFloatAsState(
        targetValue = if (isMenuExtended.value) 1f else 0f,
        animationSpec = tween(
            durationMillis = 400,
            easing = LinearEasing
        )
    ) // Fin clickAnimationProgress
    val renderEffect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        getRenderEffect().asComposeRenderEffect()
    } // Fin renderEffect
    else {
        null
    } // Fin else
    MainScreen(
        navController,
        renderEffect = renderEffect,
        fabAnimationProgress = fabAnimationProgress,
        clickAnimationProgress = clickAnimationProgress
    ) {
        isMenuExtended.value = isMenuExtended.value.not()
    } // Fin MainScreen
} // Fin MainScreen

@Composable
fun MainScreen(
    navController: NavController,
    renderEffect: androidx.compose.ui.graphics.RenderEffect?,
    fabAnimationProgress: Float = 0f,
    clickAnimationProgress: Float = 0f,
    toggleAnimation: () -> Unit = { },
) {
    Box(
        Modifier
            .fillMaxSize()
            .padding(bottom = 24.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        CustomBottomNavigation()
        Circle(
            color = MaterialTheme.colors.primary.copy(alpha = 0.5f),
            animationProgress = 0.5f
        )
        FabGroup(
            navController,
            renderEffect = renderEffect,
            animationProgress = fabAnimationProgress
        )
        FabGroup(
            navController,
            renderEffect = null,
            animationProgress = fabAnimationProgress,
            toggleAnimation = toggleAnimation
        )
        Circle(
            color = Color.White,
            animationProgress = clickAnimationProgress
        )
    } // Fin Box
} // Fin MainScreen

@Composable
fun Circle(color: Color, animationProgress: Float) {
    val animationValue = sin(PI * animationProgress).toFloat()
    Box(
        modifier = Modifier
            .padding(DEFAULT_PADDING.dp)
            .size(56.dp)
            .scale(2 - animationValue)
            .border(
                width = 2.dp,
                color = color.copy(alpha = color.alpha * animationValue),
                shape = CircleShape
            )
    ) // Fin Box
} // Fin Circle

@Composable
fun CustomBottomNavigation() {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .height(80.dp)
            .paint(
                painter = painterResource(R.drawable.bottom_navigation),
                contentScale = ContentScale.FillHeight
            )
            .padding(horizontal = 40.dp)
    ) {
        listOf(Icons.Filled.CalendarToday, Icons.Filled.Group).map { image ->
            IconButton(onClick = { }) {
                Icon(imageVector = image, contentDescription = null, tint = Color.White)
            } // Fin IconButton
        } // Fin listOf
    } // Fin Row
} // Fin CustomBottomNavigation

@Composable
fun FabGroup(
    navController: NavController,
    animationProgress: Float = 0f,
    renderEffect: androidx.compose.ui.graphics.RenderEffect? = null,
    toggleAnimation: () -> Unit = { },
) {
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { this.renderEffect = renderEffect }
            .padding(bottom = DEFAULT_PADDING.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedFab(icon = Icons.Default.PhotoCamera,
            modifier = Modifier
                .padding(
                    PaddingValues(
                        bottom = 72.dp,
                        end = 210.dp
                    ) * FastOutSlowInEasing.transform(0f, 0.8f, animationProgress)
                ),
            opacity = LinearEasing.transform(
                0.2f, 0.7f, animationProgress,
            ),
            onClick = { navController.navigate(AppNav.Home_Lista.route) }
        )
        4
        AnimatedFab(
            icon = Icons.Default.Settings,
            modifier = Modifier.padding(
                PaddingValues(
                    bottom = 88.dp,
                ) * FastOutSlowInEasing.transform(0.1f, 0.9f, animationProgress)
            ),
            opacity = LinearEasing.transform(0.3f, 0.8f, animationProgress)
        )
        AnimatedFab(
            icon = Icons.Default.ShoppingCart,
            modifier = Modifier.padding(
                PaddingValues(
                    bottom = 72.dp,
                    start = 210.dp
                ) * FastOutSlowInEasing.transform(0.2f, 1.0f, animationProgress)
            ),
            opacity = LinearEasing.transform(0.4f, 0.9f, animationProgress)
        )
        AnimatedFab(
            modifier = Modifier
                .scale(1f - LinearEasing.transform(0.5f, 0.85f, animationProgress)),
        )
        AnimatedFab(
            icon = Icons.Default.Add,
            modifier = Modifier
                .rotate(
                    225 * FastOutSlowInEasing
                        .transform(0.35f, 0.65f, animationProgress)
                ),
            onClick = toggleAnimation,
            backgroundColor = Color.Transparent
        )
    } // Fin Box
} // Fin FabGroup

@Composable
fun AnimatedFab(
    modifier: Modifier,
    icon: ImageVector? = null,
    opacity: Float = 1f,
    backgroundColor: Color = MaterialTheme.colors.secondary,
    onClick: () -> Unit = {},
) {
    FloatingActionButton(
        onClick = onClick,
        elevation = FloatingActionButtonDefaults.elevation(0.dp, 0.dp, 0.dp, 0.dp),
        backgroundColor = backgroundColor,
        modifier = modifier.scale(1.25f)
    ) {
        icon?.let {
            Icon(
                imageVector = it,,,,,,,,,,
                contentDescription = null,
                tint = Color.White.copy(alpha = opacity)
            )
        }
    } // Fin FloatingActionButton
} // Fin AnimatedFab*/
