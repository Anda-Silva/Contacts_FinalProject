package com.example.contacts.modelos

data class Contacto(
    val foto: String = "",
    val nombre: String = "",
    val telefono: String = "",
    val email: String = "",
    val sitio_web_url: String = ""
)
